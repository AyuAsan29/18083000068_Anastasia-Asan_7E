<?php
$host = "localhost";
$username = "root";
$password = "";
$db_name = "asan_db";

$koneksi = mysqli_connect($host, $username, $password, $db_name);
if (!$koneksi){
echo "gagal terhubung";
} 
?>
<?php
$host = "localhost";
$username = "root";
$password = "";
$db_name = "anastasia";

$koneksi = mysqli_connect($host, $username, $password, $db_name);
if (!$koneksi){
echo "gagal terhubung";
} 
?>
<?php include("koneksi.php") ?>

<!DOCTYPE html>
<html>
<head>
    <title>DATA PEKERJAAN</title>
    <link rel="stylesheet" href="style1.css">
</head>

<body>
    <header>
        <h2>ORANG YANG MENDAFTAR KERJA</h2>
    </header>

    <nav>
        <a href="daftar.php">[+] Penambahan Pekerjaan</a>
    </nav>

    <br>

    <table border="1">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Agama</th>
            <th>Pekerjaan</th>
        </tr>
    </thead>
    <tbody>

        <?php
        $sql = "SELECT * FROM karyawan ";
        $query = mysqli_query($koneksi, $sql);

        while($karyawan = mysqli_fetch_array($query)){
            echo  "<tr>";

            echo "<td>".$karyawan ['id']."</td>";
            echo "<td>".$karyawan ['nama']."</td>";
            echo "<td>".$karyawan ['alamat']."</td>";
            echo "<td>".$karyawan ['agama']."</td>";
            echo "<td>".$karyawan ['pekerjaan']."</td>";
            

            echo "<td>";
            echo "<a href='edit.php?id=".$karyawan ['id'].
            "'>Edit</a> | ";
            echo "<a href='hapus.php?id=".$karyawan ['id'].
            "'>Hapus</a>  ";
            echo "</td>";

            echo "</tr>";
        }
        ?>
    </tbody>
    </table>

      </body>
</html>
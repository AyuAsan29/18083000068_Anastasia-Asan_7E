<?php
include("koneksi.php");

if(isset($_POST['simpan'])){

    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $agama = $_POST['agama'];
    $pekerjaan = $_POST['pekerjaan'];

    $sql = " UPDATE karyawan SET nama='$nama', alamat ='$alamat', agama='$agama' , pekerjaan='$pekerjaan' WHERE id=$id";
    $query = mysqli_query($koneksi, $sql);

    if( $query ) {
        header('Location: list.php');
    } else {
        die("gagal menyimpan perubahan...");
    }

} else {
    die("akses dilarang...");
}

?>
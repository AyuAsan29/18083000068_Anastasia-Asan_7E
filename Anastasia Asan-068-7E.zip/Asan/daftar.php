<!DOCTYPE html>
<html>

<head>
    <title>DAFTAR KARYAWAN</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <h3>DAFTAR KARYAWAN</h3>
    </header>

    <form action="pendaftaran.php" method="POST">
        <fieldset>
            <p>
                <h3 style="color: maroon"> Nama </h3>
                <label for="nama"></label>
                <input type="text" name="nama"
                placeholder="nama lengkap" />
            </p>
            <p>
            <h3 style="color: maroon"> Alamat </h3>
                <label for="alamat"></label>
                <input type="text" name="alamat"
                placeholder="alamat" />
            </p>
            <p>
                <h3 style="color: maroon"> Agama </h3>
                <label for="nama"></label>
                <input type="text" name="agama"
                placeholder="agama" />
            </p>
            <p>
                <h3 style="color: maroon"> Pekerjaan</h3>
                <label for="pekerjaan"></label>
                <input type="text" name="pekerjaan"
                placeholder="pekerjaan" />
            </p>
            <p>
                <input type="submit" value="Daftar"
                name="daftar" />
            </p>
        </fieldset>
    </form>
</body>
</html>
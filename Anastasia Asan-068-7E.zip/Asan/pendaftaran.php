<?php

include("koneksi.php");

if(isset($_POST['daftar'])){

    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];
    $agama= $_POST['agama'];
    $pekerjaan= $_POST['pekerjaan'];

    $sql = "INSERT INTO karyawan (nama, alamat, agama, pekerjaan) VALUE
    ('$nama', '$alamat', '$agama', '$pekerjaan')";
    $query = mysqli_query($koneksi, $sql);

    if( $query ) {
        header('Location: list.php?status=sukses');
    } else {
        header('Location: index.php?status=gagal');
    }

} else {
    die("Akses dilarang...");
}

?>
<?php

include("koneksi.php");

if( !isset($_GET['id']) ){
    header('Location: list.php');
}

$id = $_GET['id'];

$sql = "SELECT * FROM karyawan WHERE id=$id";
$query = mysqli_query($koneksi, $sql);
$siswa = mysqli_fetch_assoc($query);

if( mysqli_num_rows($query) < 1 ){
    die("data tidak ditemukan...");
}

?>


<!DOCTYPE html>
<html>
<head>
    <title>Data Pekerjaan</title>
</head>

<body>
    <header>
        <h3>Data Pekerjaan</h3>
    </header>

    <form action="edits.php" method="POST">
        <fieldset>
            <input type="hidden" name="id" value="<?php echo $siswa['id'] ?>" />

         <p>
            <label for="nama">Nama: </label>
            <input type="text" name="nama"
            placeholder="namalengkap" value="<?php echo $siswa['nama'] ?>" />
        </p>
        <p>
            <label for="alamat">Alamat: </label>
            <input type="text" name="alamat"
            placeholder="alamat" value="<?php echo $siswa['alamat'] ?>" />
        </p>
        <p>
            <label for="agama">Agama: </label>
            <input type="text" name="agama"
            placeholder="agama" value="<?php echo $siswa['agama'] ?>" />
        </p>
        <p>
            <label for="pekerjaan">pekerjaan: </label>
            <input type="text" name="pekerjaan"
            placeholder="pekerjaan" value="<?php echo $siswa['pekerjaan'] ?>" />
        </p>
        <p>
            <input type="submit" value="simpan" name="simpan"/>
        </p>

        </fieldset>

    </form>

    </body>

</html>

